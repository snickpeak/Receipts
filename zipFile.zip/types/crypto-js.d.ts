declare module "crypto-js";
